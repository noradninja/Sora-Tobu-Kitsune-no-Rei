using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace Vita
	{
		public class SystemSettings
		{
			// Constants from power.h
			public const uint PowerSettingNormal = 0x00000080U;
			public const uint PowerSettingHighNoWifi = 0x00000800U;
			public const uint PowerSettingHigh = 0x00010880U;

			[DllImport("SystemSettings")]
			private static extern bool PrxSystemSettingsSetPowerLevel(uint level);
			[DllImport("SystemSettings")]
			private static extern uint PrxSystemSettingsGetPowerLevel();
			[DllImport("SystemSettings")]
			private static extern bool PrxBgmAcquire();
			[DllImport("SystemSettings")]
			private static extern bool PrxBgmRelease();
			[DllImport("SystemSettings")]
			private static extern bool PrxIsBgmAquired();

			public static bool SetPowerLevel(uint level)
			{
				return PrxSystemSettingsSetPowerLevel(level);
			}

			public static uint GetPowerLevel()
			{
				return PrxSystemSettingsGetPowerLevel();
			}
			
			public static bool BGMAcquire()
			{
				return PrxBgmAcquire();
			}

			public static bool BGMRelease()
			{
				return PrxBgmRelease();
			}

			public static bool BGMIsAcquired()
			{
				return PrxIsBgmAquired();
			}

		} // SystemSettings
	} // Vita
} // Sony
