#include <stdio.h>
#include <kernel.h>
#include <moduleinfo.h>
#include <libsysmodule.h>

#include "prx.h"
#include "SystemSettings.h"

SCE_MODULE_INFO(SavedGameList, SCE_MODULE_ATTR_NONE, 1, 1);

extern "C" int module_start(SceSize sz, const void* arg)
{
	return SCE_KERNEL_START_SUCCESS;
}
