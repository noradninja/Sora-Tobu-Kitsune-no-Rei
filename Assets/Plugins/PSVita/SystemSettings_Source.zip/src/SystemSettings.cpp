#include "SystemSettings.h"

namespace UnitySystemSettings
{
	SystemSettings gSystemSettings;

	PRX_EXPORT SceUInt32 PrxSystemSettingsGetPowerLevel()
	{
		return gSystemSettings.GetPowerConfigurationMode();
	}

	PRX_EXPORT bool PrxSystemSettingsSetPowerLevel(SceUInt32 level)
	{
		return gSystemSettings.SetPowerConfigurationMode(level);
	}

	PRX_EXPORT bool PrxBgmAcquire()
	{
		return gSystemSettings.BgmPortAcquire();
	}

	PRX_EXPORT bool PrxBgmRelease()
	{
		return gSystemSettings.BgmPortRelease();
	}

	PRX_EXPORT bool PrxIsBgmAquired()
	{
		return gSystemSettings.BgmPortIsAquired();
	}

	SystemSettings::SystemSettings()
		: m_PowerConfigMode(SCE_POWER_CONFIGURATION_MODE_A)
	{
	}

	SystemSettings::~SystemSettings() {}

	bool SystemSettings::SetPowerConfigurationMode(SceUInt32 mode)
	{
		m_PowerConfigMode = mode;
		int err = SCE_OK;
		err = scePowerSetConfigurationMode(m_PowerConfigMode);
		SCE_DBG_ASSERT(err == SCE_OK);
		return err == SCE_OK;
	}

	SceUInt32 SystemSettings::GetPowerConfigurationMode(void)
	{
		return m_PowerConfigMode;
	}

	bool SystemSettings::BgmPortAcquire()
	{
		int ret = sceAppMgrAcquireBgmPort();
		return ret == SCE_OK;
	}

	bool SystemSettings::BgmPortRelease()
	{
		int ret = sceAppMgrReleaseBgmPort();
		return ret == SCE_OK;
	}

	bool SystemSettings::BgmPortIsAquired()
	{
		int ret = sceAudioOutGetAdopt(SCE_AUDIO_OUT_PORT_TYPE_BGM);
		return ret != 0;
	}
}
