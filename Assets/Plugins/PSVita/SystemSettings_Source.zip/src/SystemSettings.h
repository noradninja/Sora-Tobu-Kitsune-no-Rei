#ifndef _SYSTEMSETTINGS_H
#define _SYSTEMSETTINGS_H

#include "prx.h"
#include <power.h>
#include <appmgr.h>
#include <audioout.h>

namespace UnitySystemSettings
{
	PRX_EXPORT SceUInt32 PrxSystemSettingsGetPowerLevel(void);
	PRX_EXPORT bool PrxSystemSettingsSetPowerLevel(SceUInt32 level);

	PRX_EXPORT bool PrxBgmAcquire();
	PRX_EXPORT bool PrxBgmRelease();

	class SystemSettings
	{
		enum {
			PowerSettingNormal,
			PowerSettingHighNoWifi,
			PowerSettingHigh
		};

	public:
		SystemSettings();
		~SystemSettings();

		bool SetPowerConfigurationMode(SceUInt32 mode);
		SceUInt32 GetPowerConfigurationMode(void);

		bool BgmPortAcquire();
		bool BgmPortRelease();
		bool BgmPortIsAquired();

	private:
		SceUInt32 m_PowerConfigMode;
	};

	extern SystemSettings gSystemSettings;
}

#endif // _SYSTEMSETTINGS_H
